package expense.contoller;

import expense.model.SmartAlert;
import expense.model.SmartAlertsManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/alerts")
@CrossOrigin
public class SmartAlertsController {

    @Autowired
    private SmartAlertsManager alertsManager;

    @GetMapping("/{email}")
    public List<SmartAlert> getAlerts(@PathVariable String email) {
        return alertsManager.generateAlerts(email);
    }
    
    @PutMapping("/read/{alertId}")
    public void markAlertAsRead(@PathVariable Long alertId) {
        alertsManager.markAlertAsRead(alertId);
    }

}
