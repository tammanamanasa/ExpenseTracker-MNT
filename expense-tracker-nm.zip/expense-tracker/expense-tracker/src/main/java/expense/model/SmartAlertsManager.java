package expense.model;

import expense.repository.SmartAlertRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class SmartAlertsManager {

    @Autowired
    private SmartAlertRepository smartAlertRepository;

    @Autowired
    private BudgetService budgetService;
    
    @Autowired
    private EmailService emailService;

    @Autowired
    private UsersManager userService;

    public List<SmartAlert> generateAlerts(String userEmail) {
        Users user = userService.getUserDetails(userEmail);
        if (user == null || !user.isReceiveAlerts()) {
            return List.of(); // No alerts if user does not exist or does not want alerts
        }

        List<Budget> budgets = budgetService.getBudgetsByUser(userEmail);

        for (Budget budget : budgets) {
            double spent = budget.getSpentAmount();
            double limit = budget.getBudgetAmount();

            // 1. Budget Exceeded Alert
            if (spent >= limit) {
                createOrUpdateSmartAlert(userEmail, "Budget Exceeded",
                        String.format("You have exceeded your budget in the '%s' category. You spent %.2f out of %.2f.",
                                budget.getCategory(), spent, limit));
            }

            // 2. Nearing Budget Alert (80%)
            else if (spent >= limit * 0.8) {
                createOrUpdateSmartAlert(userEmail, "Budget Nearing",
                        String.format("You are nearing your budget in the '%s' category. You have spent %.2f out of %.2f.",
                                budget.getCategory(), spent, limit));
            }
        }

        // Return only non-expired alerts
        return smartAlertRepository.findByUserEmailAndExpiresAtAfter(userEmail, LocalDateTime.now());
    }

    private void createOrUpdateSmartAlert(String email, String type, String message) {
        SmartAlert existingAlert = smartAlertRepository.findByUserEmailAndAlertType(email, type);
        if (existingAlert == null) {
            SmartAlert alert = new SmartAlert();
            alert.setUserEmail(email);
            alert.setAlertType(type);
            alert.setMessage(message);
            alert.setCreatedAt(LocalDateTime.now());
            alert.setExpiresAt(LocalDateTime.now().plusDays(30)); // Expires in 30 days
            smartAlertRepository.save(alert);

            // Send email only for new alerts
            emailService.sendAlertEmail(email, "Smart Alert: " + type, message);
        } else {
            // Update existing alert with the latest message
            existingAlert.setMessage(message);
            existingAlert.setCreatedAt(LocalDateTime.now());
            existingAlert.setExpiresAt(LocalDateTime.now().plusDays(30)); // Reset expiration
            smartAlertRepository.save(existingAlert);
        }
    }
    
    public void markAlertAsRead(Long alertId) {
        SmartAlert alert = smartAlertRepository.findById(alertId).orElse(null);
        if (alert != null) {
            alert.setRead(true);
            smartAlertRepository.save(alert);
        }
    }

}
