package expense.model;

import java.util.Date;


import java.util.List;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.*;


@Entity
@Table(name = "expense_users")
public class Users {
    
    @Column(name = "fullname")
    private String fullname;
    
    @Id
    @Column(name = "email")
    private String email;
    
    @Column(name = "password")
    private String password;
    
    @Column(name = "reset_token")
    private String resetToken;  

    @Column(name = "token_expiry")
    @Temporal(TemporalType.TIMESTAMP)
    private Date tokenExpiry;
    
    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JsonManagedReference
    private List<Transaction> userTransactions;  // ✅ Change variable name to avoid conflicts
    
    private boolean receiveAlerts = true; // Default is true

    

    // Getters and Setters
    public String getFullname() { 
    	return fullname;
    }
    public void setFullname(String fullname) { 
    	this.fullname = fullname; 
    }

    public String getEmail() { 
    	return email; 
    }
    public void setEmail(String email) { 
    	this.email = email; 
    }

    public String getPassword() { 
    	return password; 
    }
    public void setPassword(String password) {
    	this.password = password; 
    }

    public String getResetToken() { 
    	return resetToken; 
    }
    public void setResetToken(String resetToken) {
    	this.resetToken = resetToken;
    }

    public Date getTokenExpiry() { 
    	return tokenExpiry; 
    }
    public void setTokenExpiry(Date tokenExpiry) { 
    	this.tokenExpiry = tokenExpiry; 
    }
    public List<Transaction> getUserTransactions() {
        return userTransactions;
    }

    public void setUserTransactions(List<Transaction> userTransactions) {
        this.userTransactions = userTransactions;
    }
    
    public boolean isReceiveAlerts() {
        return receiveAlerts;
    }

    public void setReceiveAlerts(boolean receiveAlerts) {
        this.receiveAlerts = receiveAlerts;
    }

    @Override
    public String toString() {
        return "Users [fullname=" + fullname + ", email=" + email + ", password=" + password + "]";
    }
}
