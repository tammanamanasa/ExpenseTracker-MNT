package expense.model;

import expense.repository.BudgetRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.util.List;

@Service
public class BudgetService {

    @Autowired
    private BudgetRepository budgetRepository;
    
    @Autowired
    private EmailManager emailManager; // ✅ Properly Injected

    public List<Budget> getBudgetsByUser(String userEmail) {
        return budgetRepository.findByUserEmail(userEmail);
    }

    public Budget addBudget(Budget budget) {
        return budgetRepository.save(budget);
    }

    public void deleteBudget(Long id) {
        budgetRepository.deleteById(id);
    }
    
    public void updateSpentAmount(String userEmail, String category, double amount, boolean isAddition) {
        List<Budget> budgets = budgetRepository.findByUserEmail(userEmail);
        for (Budget b : budgets) {
            if (b.getCategory().equalsIgnoreCase(category)) {
                double newSpent = isAddition ? b.getSpentAmount() + amount : b.getSpentAmount() - amount;
                b.setSpentAmount(Math.max(newSpent, 0)); // Avoid negatives
                budgetRepository.save(b);
                break;
            }
        }
    }

    // ✅ Auto-Reset Budgets Monthly
    @Scheduled(cron = "0 0 0 1 * ?") // Runs at midnight on the 1st of every month
    public void resetBudgetsMonthly() {
        List<Budget> budgets = budgetRepository.findAll();
        for (Budget b : budgets) {
            // Reset spent amount and update reset date
            b.setSpentAmount(0);
            b.setResetDate(LocalDate.now().withDayOfMonth(1).plusMonths(1));
            budgetRepository.save(b);

            // ✅ Send email notification using EmailManager
            String subject = "Your Monthly Budget has been Reset";
            String message = String.format(
                "Hello,\n\nYour budget for the category '%s' has been reset for the new month.\n" +
                "You can now start tracking your expenses again.\n\nThank you for using Artha Guru.", 
                b.getCategory());

            emailManager.sendEmail(b.getUserEmail(), subject, message);
        }
    }
}
