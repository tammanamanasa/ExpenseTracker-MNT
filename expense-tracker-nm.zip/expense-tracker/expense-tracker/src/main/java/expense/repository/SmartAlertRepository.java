package expense.repository;

import expense.model.SmartAlert;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface SmartAlertRepository extends JpaRepository<SmartAlert, Long> {
    List<SmartAlert> findByUserEmail(String email);
    List<SmartAlert> findByUserEmailAndExpiresAtAfter(String email, LocalDateTime now);
    SmartAlert findByUserEmailAndAlertType(String email, String alertType);
    List<SmartAlert> findByUserEmailAndReadFalse(String email);
}
